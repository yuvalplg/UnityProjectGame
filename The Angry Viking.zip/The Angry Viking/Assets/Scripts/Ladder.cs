using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ladder : MonoBehaviour
{
    private float vertical;
    private float speed = 8f;
    private bool isLadder;
    private bool isclimbing;

    [SerializeField] private Rigidbody2D body;

    void Update()
    {
        vertical = Input.GetAxis("Vertical");

        if(isLadder && Mathf.Abs(vertical) > 0f)
        {
            isclimbing = true;
        }
    }

    private void FixedUpdate()
    {
        if (isclimbing)
        {
            body.gravityScale = 0f;
            body.velocity = new Vector2(body.velocity.x, vertical * speed);
        }
        else
        {
            body.gravityScale = 4f;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.tag == "Ladder")
        {
            isLadder = true;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.tag == "Ladder")
        {
            isLadder = false;
            isclimbing = false;
        }
    }
}
