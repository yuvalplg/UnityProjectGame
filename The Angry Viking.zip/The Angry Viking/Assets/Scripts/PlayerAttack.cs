using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAttack : MonoBehaviour
{
    [SerializeField] private float attackCooldown;
    private Animator anim;
    private PlayerMovement playerMovement;
    private float cooldownTimer = Mathf.Infinity;

    [Header("Attacking Enemies")]
    public Transform attackLocation;
    public LayerMask enemyLayer;
    public LayerMask trapLayer;
    public LayerMask boxLayer;
    public float attackRange;

    int damege;

    private void Awake()
    {
        anim = GetComponent<Animator>();
        playerMovement = GetComponent<PlayerMovement>();
        damege = Random.Range(2, 5);

    }

    private void Update()
    {
        if ((Input.GetKey(KeyCode.Z)) && cooldownTimer > attackCooldown)
            Attack();

        cooldownTimer += Time.deltaTime;
    }

    private void Attack()
    {
        anim.SetTrigger("attack");

        cooldownTimer = 0;
    }

    private void AttackEnemy()
    {
        //enemies
        Collider2D[] enemies = Physics2D.OverlapCircleAll(attackLocation.position, attackRange, enemyLayer);
        foreach (Collider2D enemy in enemies)
        {
            
                enemy.GetComponent<Health>().TakeDamege(damege); 


        }
       

    }

    void OnDrawGizmosSelected()
    {
        
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(attackLocation.position, attackRange);
    }


}
