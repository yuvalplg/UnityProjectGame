using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Chest : MonoBehaviour
{
    [SerializeField] private int goldValue;
    private bool open;
   
    private Animator anim;


    private void Awake()
    {
        anim = GetComponent<Animator>();
        

    }

   

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player" && !open)
        {
            anim.SetBool("close", false);
            collision.GetComponent<Gold>().AddGold(goldValue);
            open = true;
            
        }
    }
}
