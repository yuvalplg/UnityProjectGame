using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GoldBar : MonoBehaviour
{
    [SerializeField] private Gold playerGold;
    [SerializeField] private Image requiredGoldBar;
    [SerializeField] private Image currentGoldBar;

    private void start()
    {
        requiredGoldBar.fillAmount = playerGold.currentGold / 10;
    }

    private void Update()
    {
        currentGoldBar.fillAmount = playerGold.currentGold / 10;
    }
}
