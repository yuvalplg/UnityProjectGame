using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gold : MonoBehaviour
{






    public int currentGold = 0;
    
    [SerializeField] private int GoldRequired;

    public void AddGold(int _value)
    {
        currentGold += _value;
    }

    public bool GotAllGold()
    {
        if (currentGold >= GoldRequired)
            return true;
        return false;
    }
}
