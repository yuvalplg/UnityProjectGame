using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Box : MonoBehaviour
{
    public GoldItem goldItem;

    public void destroy()
    {
        Destroy(gameObject);
        GoldItem gh_item = Instantiate(goldItem, gameObject.transform.position, Quaternion.identity);
    }
}
