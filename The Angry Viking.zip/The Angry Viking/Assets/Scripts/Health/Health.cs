using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Health : MonoBehaviour
{
    [Header("Health")]
    [SerializeField] private float fullHealth;
    public float currentHealth { get; private set; }
    private Animator anim;
    private bool dead = false;

    [Header("iFrames")]
    [SerializeField] private float iframeDuration;
    [SerializeField] private int numOfFlashes;
    private SpriteRenderer spriteRend;

    private RestartGame restart;

    public HealthItem healthItem;

    



    private void Awake()
    {
        currentHealth = fullHealth;
        anim = GetComponent<Animator>();
        spriteRend = GetComponent<SpriteRenderer>();
    }

    public void TakeDamege(float damage)
    {
        //damage taken 
        currentHealth = Mathf.Clamp(currentHealth - damage, 0, fullHealth);

        if(currentHealth > 0)
        {
            anim.SetTrigger("hurt");
            StartCoroutine(Invun());
        }
        else
        {
            if (!dead)
            {

                anim.SetTrigger("die");

                if (gameObject.tag == "Player")
                {
                    SceneManager.LoadScene(SceneManager.GetActiveScene().name);
                }


                //Player
                if (GetComponent<PlayerMovement>()!=null)
                     GetComponent<PlayerMovement>().enabled = false;

                

                //Enemy
                if (GetComponent<EnemyPatrol>() != null)
                    GetComponent<EnemyPatrol>().enabled = false;

                if (GetComponent<EnemyKnight>() != null)
                    GetComponent<EnemyKnight>().enabled = false;

                StartCoroutine(destroy());



            }
            dead = true;

        }

    }

    public void AddHealth(float _value)
    {
        currentHealth = Mathf.Clamp(currentHealth + _value, 0, fullHealth);
    }

   private IEnumerator Invun()
    {
        Physics2D.IgnoreLayerCollision(10, 11, true);
        for (int i = 0; i < numOfFlashes; i++)
        {
            spriteRend.color = new Color(1, 0, 0, 0.5f);
            yield return new WaitForSeconds(iframeDuration / (numOfFlashes * 2));
            spriteRend.color = Color.white;
            yield return new WaitForSeconds(iframeDuration / (numOfFlashes * 2));
        }
        Physics2D.IgnoreLayerCollision(10, 11, false);
    }

    private IEnumerator destroy()
    {
        if (gameObject.tag == "Enemy")
        {
            anim.SetTrigger("die");
            if (GetComponent<EnemyPatrol>() != null)
                GetComponent<EnemyPatrol>().enabled = false;
            yield return new WaitForSeconds(2);

            Destroy(gameObject);
            HealthItem h_item = Instantiate(healthItem, gameObject.transform.position, Quaternion.identity);
            




        }
        
        if (gameObject.tag == "EnemyBoss")
        {
            anim.SetTrigger("die");
            if (GetComponent<EnemyPatrol>() != null)
                GetComponent<EnemyPatrol>().enabled = false;
            yield return new WaitForSeconds(2);

            Destroy(gameObject);
            HealthItem h_item = Instantiate(healthItem, gameObject.transform.position, Quaternion.identity);
            




        }
    }
}
