using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MoveToNextLevel : MonoBehaviour
{
    

    [SerializeField] private Transform nextRoom;
    [SerializeField] private string InOrOut;

    void OnTriggerEnter2D(Collider2D collider)
    {
        if ( collider.tag == "Player")
        {
            
                if(InOrOut == "in")
                  collider.transform.position = new Vector3(nextRoom.transform.position.x + 4f, nextRoom.transform.position.y, nextRoom.transform.position.z);
                if(InOrOut == "out")
                  collider.transform.position = new Vector3(nextRoom.transform.position.x - 4f, nextRoom.transform.position.y, nextRoom.transform.position.z);

        }
    }
}

