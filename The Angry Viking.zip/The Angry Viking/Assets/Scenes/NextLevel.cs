using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class NextLevel : MonoBehaviour
{
    [SerializeField] private string newLevel;

    
    

    void OnTriggerEnter2D(Collider2D collider)
    {
        if (collider.tag == "Player")
        {
            //move to next level
            if (collider.GetComponent<Gold>().GotAllGold())
                SceneManager.LoadScene(newLevel);
           
           

        }

        
    }
}
